
Following test cases assume 10 childred.
Run the test program as  ...
$testcase 10

Input test cases:

1. Child i has priority (i+1);
   i.e., priority of children 0 to n-1 varies from 1 to n

2. Child i has priority N-i (where N is number of childred)
   i.e.,. priority of children 0 to N-1 varies from N to 1

3. All children have same priority, set to 5. 
