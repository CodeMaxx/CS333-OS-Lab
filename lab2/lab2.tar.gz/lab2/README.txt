=================================================================================
									README
=================================================================================

There is a lab2.pdf which contains the problem statements.

Also we have provided the sample binaries for all the tasks to verify the outputs.

INSTRUCTIONS TO RUN THE SCRIPTS:

Task 1:
./simple_fork

Task 2:
./smart_file_write

Task 3:
./my_head <int> <file name> 
Example: ./my_head 10 sample.txt

Task 4:
./multi_head <file1> <file2> <file3> ...
Example: ./multi_head sample.txt sample.txt sample.txt

Task 5:
./write_head <int> <input file> <output file> 
Example: ./write head 10 input.txt output.txt

Task 6:
./safe_control_c