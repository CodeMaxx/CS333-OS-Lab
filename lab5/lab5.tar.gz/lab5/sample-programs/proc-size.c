#include "types.h"
#include "stat.h"
#include "user.h"

int getpusz()
{
	//	Implment getpuz() here.
	retun 0;
}
int getpksz()
{
	//	Implment getpksz() here.
	retun 0;
}

int getptsz()
{
	//	Implment getptsz() here.
	retun 0;
}

int
main(int argc, char *argv[])
{
	char *buf;

	printf(1,"\ngetpusz: %d bytes \n",getpusz());
	printf(1,"getpksz: %d bytes\n",getpksz());
	printf(1,"getptsz: %d bytes\n",getptsz());


	buf=sbrk(4096);
	buf[0]='\0';
	printf(1,"\ngetpusz: %d bytes \n",getpusz());
	printf(1,"getpksz: %d bytes\n",getpksz());
	printf(1,"getptsz: %d bytes\n",getptsz());

	
	buf=sbrk(4096*7);
	printf(1,"\ngetpusz: %d bytes \n",getpusz());
	printf(1,"getpksz: %d bytes\n",getpksz());
	printf(1,"getptsz: %d bytes\n",getptsz());

	exit();
}