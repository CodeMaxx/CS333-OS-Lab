#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#include "emufs.h"
#include <time.h>

/*
	----------------DEVICE------------------
*/
int EMULATED_DISK_FD=-1;

int opendevice(char *device_name, int size)
{

	/*
		* It opens the the emulated deive.
		* If emulated device file is not exit
			* Create emulated disk file.
			* Creates superblocks and writes to disk.
			* file system type on newly created superblock will be null or '0'
		* It returns 2, if a file sytem exits on the deivce. Other wise return 1.
		* In case of any error, it returns -1.
	*/

	if(size > MAX_BLOCKS || size<2)
	{
		printf("Invalid Disk Size\n");
		return -1;
	}

	FILE *fp;
	int fd;
	fp = fopen(device_name, "r");
	struct superblock_t *superblock;
	
	if(!fp)
	{
		//	Creating the device
		printf("Creating disk. \n");
		
		superblock = (struct superblock_t*)malloc(sizeof(struct superblock_t));
		strcpy(superblock->name,device_name);
		strcpy(superblock->fstype,"0");
		superblock->disk_size=size;

		fp = fopen(device_name, "w+");
		if(!fp)
		{
			printf("Error : Unable to create device. \n");
			free(superblock);
			return -1;
		}
		fd = fileno(fp);
		
		// Make size of the disk as the total size
        fseek(fp, size*BLOCKSIZE, SEEK_SET);
        fputc('\0', fp);

		fseek(fp, 0, SEEK_SET);
		char tempBuf[BLOCKSIZE];
		memcpy(tempBuf, superblock, sizeof(struct superblock_t));
		write(fd, tempBuf, BLOCKSIZE);

		printf("New disk created\n");
		EMULATED_DISK_FD = fd;	// Set the current device as the file descriptor of the disk file
		free(superblock);
		return 1;		// File system does not exist.

	}
	else
	{
		fclose(fp);
		fd = open(device_name, O_RDWR);
		printf("Disk exists. \n");
		EMULATED_DISK_FD = fd;

		char tempBuf[BLOCKSIZE];
		superblock = (struct superblock_t*)malloc(sizeof(struct superblock_t));

		read(EMULATED_DISK_FD, tempBuf,BLOCKSIZE);
		memcpy(superblock,tempBuf,sizeof(struct superblock_t));
		if(strcmp(superblock->fstype,"0")==0)
		{
			// File system does not exist.
			printf("File system not found on this disk \n");
			free(superblock);
			return 1;
		}
		else
		{
			printf("File system on the disk : %s \n",superblock->fstype);
			free(superblock);
			return 2;
		}
	}
	
	
}

int writedevice(int block, char * buf)
{
	
	if(EMULATED_DISK_FD < 0)
	{
		printf("No Device is open\n");
		return -1;
	}
	int offset=block * BLOCKSIZE;
	lseek(EMULATED_DISK_FD, offset, SEEK_SET);
	int ret=write(EMULATED_DISK_FD, buf, BLOCKSIZE);
	if(ret!=BLOCKSIZE)
	{
		printf("Error: Disk write error. \n");
		return -1;
	}
	return 1;
}

int readdevice(int block, char * buf)
{
	if(EMULATED_DISK_FD < 0)
	{
		printf("No Device is open\n");
		return -1;
	}
	int offset=block * BLOCKSIZE;
	lseek(EMULATED_DISK_FD, offset, SEEK_SET);
	int ret=read(EMULATED_DISK_FD, buf, BLOCKSIZE);
	if(ret!=BLOCKSIZE)
	{
		printf("Error: Disk read error. \n");
		return -1;
	}
	return 1;
}

int closedevice()
{
	if(EMULATED_DISK_FD < 0)
	{
		printf("No Device is open\n");
		return -1;
	}
	close(EMULATED_DISK_FD);
	EMULATED_DISK_FD = -1;

	return 1;
}

void fsdump()
{
	//
}


/*
	----------------HELPER FUNCTIONS------------------
*/

struct superblock_t* readSuperblock()
{
	/*
		* Read 0th block from the device into a blocksize buffer
		* Create superblock_t variable and fill it using reader buffer
		* Return the superblock_t variable
	*/
}

int writeSuperblock(struct superblock_t *superblock)
{
	/*
		* Write the superblock into the buffer
		* Write back the buffer into block 0
	*/
}

struct metadata_t* readMetadata()
{
	// Same as readSuperBlock(), but it is stored on block 1
}

int writeMetadata(struct metadata_t *metadata)
{
	// Same as writeSuperblock(), but it is stored on block 1
}

/*
	----------------FILE SYSTEM API------------------
*/

int create_file_system()
{
	/*
	   	* Read the superblock.
	    * Set file system type on superblock as 'emufs'
		* Clear the bitmaps.  values on the bitmap will be either '0', or '1', or'x'. 
		* Create metadata block in disk
		* Write superblocka nd metadata block back to disk.
	*/
}

struct file_t* eopen(char * filename)
{
	/* 
		* If file exist, get the inode number. inode number is the index of inode in the metadata.
		* If file does not exist, 
			* find free inode.
			* allocate the free inode as USED
			* if free id not found, print the error and return -1
		* Create the file hander (struct file_t)
		* Initialize offsetin the file hander
		* Return file handler.
	*/
}

int ewrite(struct file_t* file, char* data, int size)
{
	// You do not need to implement partial writes in case file exceeds 4 blocks
	// or no free block is available in the disk. 
}

int eread(struct file_t* file, char* data, int size)
{
	// NO partial READS.
}

void eclose(struct file_t* file)
{
	// free the memory allocated for the file handler 'file'
}

int eseek(struct file_t *file, int offset)
{
	// Chnage the offset in file hanlder 'file'
}

int etruncate(struct file_t *file, int n)
{
	/*
		* Truncate last n blocks allocated a file referred by the file hanlder 'file'
		* If n is greater than the blocks allocated, remove all blocks.
		* It should return the actual number of blocks truncated.

		* Read the metadata & superblock from disk.
		* Remove the last n blocks allocated in inode of a file
		* Add the those truncated blocks into free list(Update bitmap)
		* Write metadata and superblock back to disk
	*/
}

