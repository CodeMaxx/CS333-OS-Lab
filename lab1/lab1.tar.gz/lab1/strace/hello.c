#include <stdio.h>

int main () 
{
	char name[50];
	
	printf("\nEnter your name : ");
	scanf("%s",name);
	printf("\nWelcome %s\n",name);
	
	return 0;
} 

