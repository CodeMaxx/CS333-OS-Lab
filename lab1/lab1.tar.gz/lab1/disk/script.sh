i=0
while (( i++ < 10000 )); do
  cp ./files/foo.pdf "./files/foo$i.pdf"
done
